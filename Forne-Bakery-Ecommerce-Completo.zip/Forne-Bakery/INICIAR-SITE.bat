@echo off
chcp 65001 >nul
cd /d "%~dp0backend"
where node >nul 2>&1
if errorlevel 1 (
    echo Node.js nao encontrado. Instale o Node.js LTS 22.13+ em https://nodejs.org/
    pause
    exit /b 1
)
start "Forne Bakery - Servidor" cmd /k "npm start"
timeout /t 3 /nobreak >nul
start "" "http://localhost:3000"
