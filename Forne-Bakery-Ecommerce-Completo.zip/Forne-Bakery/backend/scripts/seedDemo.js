'use strict';
const {db,passwd}=require('../db');
const {randomBytes}=require('node:crypto');
if(db.prepare('SELECT count(*) count FROM orders').get().count){console.log('Exemplos já presentes.');process.exit(0)}
const day=n=>{const d=new Date(Date.now()+n*86400000);return new Intl.DateTimeFormat('sv-SE',{year:'numeric',month:'2-digit',day:'2-digit',timeZone:'America/Sao_Paulo'}).format(d)};
const examples=[
 {name:'Cliente Demonstração',email:'cliente@forne.com.br',phone:'11988881111',product:1,qty:2,slot:day(1)+'T09:30',fulfillment:'pickup',pay:'card',status:'em_preparo'},
 {name:'Ana Martins (exemplo)',email:'ana@exemplo.test',phone:'11988882222',product:5,qty:1,slot:day(2)+'T15:00',fulfillment:'delivery',address:'Rua Exemplo, 123 - Centro',pay:'pix',status:'recebido',options:{size:'2 kg · até 16 fatias',filling:'Morango com creme',message:'Parabéns, Sofia!'}},
 {name:'Bruno Lima (exemplo)',email:'bruno@exemplo.test',phone:'11988883333',product:11,qty:3,slot:day(1)+'T13:00',fulfillment:'pickup',pay:'card',status:'pronto'},
 {name:'Carla Rocha (exemplo)',email:'carla@exemplo.test',phone:'11988884444',product:8,qty:4,slot:day(1)+'T14:00',fulfillment:'delivery',address:'Avenida Fictícia, 20 - Centro',pay:'meal',status:'concluido'},
 {name:'Diego Alves (exemplo)',email:'diego@exemplo.test',phone:'11988885555',product:2,qty:2,slot:day(2)+'T09:00',fulfillment:'pickup',pay:'pix',status:'recebido',pending:true},
];
const items={};for(const p of db.prepare('SELECT * FROM products').all())items[p.id]=p;
db.exec('BEGIN IMMEDIATE');try{
 for(const e of examples){let user=db.prepare('SELECT id FROM users WHERE email=?').get(e.email);if(!user){const salt=randomBytes(16).toString('hex');const r=db.prepare('INSERT INTO users(name,email,phone,salt,hash,role) VALUES(?,?,?,?,?,?)').run(e.name,e.email,e.phone,salt,passwd('Cliente@123',salt),'customer');user={id:r.lastInsertRowid}}
 const p=items[e.product];let unit=p.price_cents;if(e.options?.size==='2 kg · até 16 fatias')unit+=7900;if(e.options?.filling==='Morango com creme')unit+=1200;const sub=unit*e.qty,delivery=e.fulfillment==='delivery'&&sub<8000?790:0;const code='FR-DEF'+String(examples.indexOf(e)+1).padStart(5,'0');
 const result=db.prepare('INSERT INTO orders(code,user_id,customer_name,email,phone,fulfillment,address,slot,notes,payment_method,payment_status,status,subtotal_cents,delivery_cents,total_cents) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(code,user.id,e.name,e.email,e.phone,e.fulfillment,e.address||'',e.slot,'Pedido demonstrativo',e.pay,e.pending?'aguardando_demo':'aprovado_demo',e.status,sub,delivery,sub+delivery);
 db.prepare('INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_cents,customization_json) VALUES(?,?,?,?,?,?)').run(result.lastInsertRowid,e.product,p.name,e.qty,unit,JSON.stringify(e.options||{}));db.prepare('UPDATE products SET stock=stock-? WHERE id=?').run(e.qty,e.product);
 }
 db.exec('COMMIT');db.exec('PRAGMA wal_checkpoint(TRUNCATE)');console.log('5 pedidos fictícios incluídos para demonstrar o painel.');
}catch(err){db.exec('ROLLBACK');throw err}
