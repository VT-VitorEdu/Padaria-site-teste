'use strict';
const { DatabaseSync } = require('node:sqlite');
const { mkdirSync } = require('node:fs');
const path = require('node:path');
const { scryptSync, randomBytes } = require('node:crypto');
const dataDir = path.join(__dirname,'data');
mkdirSync(dataDir,{recursive:true});
const dbFile=process.env.FORNE_DB_PATH?path.resolve(process.env.FORNE_DB_PATH):path.join(dataDir,'forne.sqlite');
mkdirSync(path.dirname(dbFile),{recursive:true});
const db = new DatabaseSync(dbFile);
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
db.exec(`
 CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, phone TEXT DEFAULT '', salt TEXT NOT NULL, hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL, price_cents INTEGER NOT NULL CHECK(price_cents>=0), stock INTEGER NOT NULL DEFAULT 0 CHECK(stock>=0), artwork TEXT NOT NULL DEFAULT 'bread', image_url TEXT NOT NULL DEFAULT '', badge TEXT NOT NULL DEFAULT '', featured INTEGER NOT NULL DEFAULT 0, available INTEGER NOT NULL DEFAULT 1, options_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, user_id INTEGER NOT NULL REFERENCES users(id), customer_name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT NOT NULL, fulfillment TEXT NOT NULL, address TEXT NOT NULL DEFAULT '', slot TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', payment_method TEXT NOT NULL, payment_status TEXT NOT NULL, status TEXT NOT NULL, subtotal_cents INTEGER NOT NULL, delivery_cents INTEGER NOT NULL, total_cents INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE, product_id INTEGER NOT NULL, product_name TEXT NOT NULL, quantity INTEGER NOT NULL, unit_cents INTEGER NOT NULL, customization_json TEXT NOT NULL DEFAULT '{}');
 CREATE INDEX IF NOT EXISTS orders_by_date ON orders(created_at DESC);
 CREATE INDEX IF NOT EXISTS orders_by_user ON orders(user_id, created_at DESC);
 CREATE INDEX IF NOT EXISTS orders_by_status ON orders(status);
`);
function passwd(password,salt){return scryptSync(password,salt,64).toString('hex')}
function userSeed(name,email,password,role){if(!db.prepare('SELECT id FROM users WHERE email=?').get(email)) {const salt=randomBytes(16).toString('hex');db.prepare('INSERT INTO users(name,email,salt,hash,role) VALUES(?,?,?,?,?)').run(name,email,salt,passwd(password,salt),role)}}
userSeed('Equipe da cozinha','cozinha@forne.com.br','Forne@123','admin');
userSeed('Cliente Demonstração','cliente@forne.com.br','Cliente@123','customer');
const catalog = [
  ['Pão artesanal da casa','Casca douradinha, miolo macio e fermentação lenta de 18 horas.','paes',1890,42,'bread','','Mais pedido',1,{}],
  ['Croissant de manteiga','Folhado em camadas, crocante por fora e delicado por dentro.','paes',1490,38,'croissant','','Queridinho',1,{}],
  ['Pão de queijo mineiro','Porção com 6 unidades. Queijinho de verdade, quentinho e irresistível.','paes',2290,65,'cheese','','',1,{}],
  ['Baguete francesa','Receita clássica, crostinha crocante e aroma de forno recém-aberto.','paes',1390,33,'baguette','','',0,{}],
  ['Bolo de aniversário','Feito para celebrar. Escolha o peso, o recheio e uma mensagem especial.','bolos',8990,13,'cake','','Personalizável',1,{
      size:[{label:'1 kg · até 8 fatias',extra:0},{label:'2 kg · até 16 fatias',extra:7900},{label:'3 kg · até 24 fatias',extra:14900}],
      filling:[{label:'Brigadeiro',extra:0},{label:'Doce de leite',extra:800},{label:'Morango com creme',extra:1200}],message:true
  }],
  ['Bolo de cenoura & chocolate','Massa fofinha, cobertura generosa de chocolate e aquele gostinho de casa.','bolos',3890,20,'carrot','','',1,{}],
  ['Cheesecake de frutas vermelhas','Creme aveludado com calda artesanal e base amanteigada.','bolos',2690,24,'cheesecake','','Novo',0,{}],
  ['Cookie de chocolate','Grandão, com gotas de chocolate e centro macio.','doces',1290,55,'cookie','','',1,{}],
  ['Brownie intenso','Chocolate meio amargo, casquinha delicada e interior úmido.','doces',1590,47,'brownie','','',1,{}],
  ['Sonho de creme','Massa leve, recheio de baunilha e cobertura de açúcar fininho.','doces',1190,44,'donut','','',0,{}],
  ['Coxinha cremosa','Massa macia, frango bem temperado e crocância no ponto.','salgados',1190,60,'coxinha','','Mais pedido',1,{}],
  ['Quiche de alho-poró','Massa amanteigada e recheio cremoso, assado na hora.','salgados',1790,26,'quiche','','',0,{}],
  ['Empada de palmito','Recheio caprichado em uma massa que derrete na boca.','salgados',1090,39,'empada','','',0,{}],
  ['Cappuccino cremoso','Café espresso, leite vaporizado e uma pitada de cacau. 250 ml.','bebidas',1490,30,'coffee','','',0,{}],
  ['Suco natural de laranja','Espremido na hora, sem conservantes e com muito sabor. 350 ml.','bebidas',1390,27,'juice','','',0,{}],
];
if(db.prepare('SELECT COUNT(*) n FROM products').get().n === 0){
 const insert=db.prepare('INSERT INTO products(name,description,category,price_cents,stock,artwork,image_url,badge,featured,options_json) VALUES(?,?,?,?,?,?,?,?,?,?)');
 for(const p of catalog)insert.run(...p.slice(0,9),JSON.stringify(p[9]));
}
module.exports={db,passwd};
