'use strict';
/** Centraliza regras de horário e frete utilizadas no checkout. */
class FulfillmentService {
  static deliveryFeeCents(mode,subtotal){return mode==='delivery'&&subtotal<8000?790:0}
  static leadMinutes(hasCustomCake){return hasCustomCake?120:45}
}
module.exports=FulfillmentService;
