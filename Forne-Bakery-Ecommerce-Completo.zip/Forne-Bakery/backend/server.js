'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {db,passwd}=require('./db');
const Product=require('./models/Product');
const Order=require('./models/Order');
const FulfillmentService=require('./services/FulfillmentService');
const root=path.resolve(__dirname,'../frontend');
const PORT=Number(process.env.PORT)||3000;
const streams=new Set();
const allowedCategories=new Set(['paes','bolos','doces','salgados','bebidas']);
const allowedArtworks=new Set(['bread','croissant','cheese','baguette','cake','carrot','cheesecake','cookie','brownie','donut','coxinha','quiche','empada','coffee','juice']);
const statuses=['recebido','em_preparo','pronto','concluido','cancelado'];
const slotRegex=/^\d{4}-\d{2}-\d{2}T(?:0[8-9]|1[0-9]):(?:00|30)$/;
const badLogins=new Map();
const LIMIT=160_000;
const money=n=>Number.isSafeInteger(n)&&n>=0;
const safeText=(v,max=200)=>String(v??'').trim().slice(0,max);
const parseOptions=(s)=>{try{return JSON.parse(s||'{}')}catch{return {}}};
const formatted=(r)=>new Product(r).toJSON();
function json(res,status,payload,extra={}){const body=JSON.stringify(payload);res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...extra});res.end(body)}
function err(status,message){const e=new Error(message);e.status=status;throw e}
function cookies(req){return Object.fromEntries((req.headers.cookie||'').split(';').map(x=>x.trim()).filter(Boolean).map(p=>{const index=p.indexOf('=');return [p.slice(0,index),p.slice(index+1)]}))}
function auth(req){const token=cookies(req).forne_session;if(!token||!/^([a-f0-9]{64})$/.test(token))return null;const hash=crypto.createHash('sha256').update(token).digest('hex');return db.prepare('SELECT u.id,u.name,u.email,u.phone,u.role FROM sessions s JOIN users u ON s.user_id=u.id WHERE s.token_hash=? AND s.expires_at>?').get(hash,Date.now())||null}
function requires(req,role){const user=auth(req);if(!user)err(401,'Faça login para continuar.');if(role&&user.role!==role)err(403,'Acesso restrito à equipe da cozinha.');return user}
function sessionCookie(token,maxAge){return `forne_session=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}`}
function startSession(user,res){const token=crypto.randomBytes(32).toString('hex');db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').run(crypto.createHash('sha256').update(token).digest('hex'),user.id,Date.now()+7*86400000);return sessionCookie(token,7*86400)}
function privateUser(u){return {id:u.id,name:u.name,email:u.email,phone:u.phone,role:u.role}}
function bodyJson(req){return new Promise((resolve,reject)=>{let data='';req.on('data',chunk=>{data+=chunk;if(data.length>LIMIT){reject(Object.assign(new Error('Requisição grande demais.'),{status:413}));req.destroy()}});req.on('end',()=>{try{resolve(data?JSON.parse(data):{})}catch{reject(Object.assign(new Error('JSON inválido.'),{status:400}))}});req.on('error',reject)})}
function broadcast(name,data){for(const res of streams){try{res.write(`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`)}catch{streams.delete(res)}}}
function orderFull(row){if(!row)return null;return {...row,items:db.prepare('SELECT product_id,product_name,quantity,unit_cents,customization_json FROM order_items WHERE order_id=?').all(row.id).map(r=>({...r,customization:parseOptions(r.customization_json),customization_json:undefined}))}}
function currentLocal(){const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date()).filter(x=>x.type!=='literal').map(x=>[x.type,x.value]));return `${parts.year}-${parts.month}-${parts.day}T${parts.hour.padStart(2,'0')}:${parts.minute}`}
function validateSlot(slot,containsCake){if(!slotRegex.test(slot))err(400,'Selecione uma data e horário válidos entre 08h e 19h30.');const now=currentLocal();const dt=new Date(slot+':00-03:00');if(!Number.isFinite(dt.getTime()))err(400,'Data inválida.');if(dt.getTime()<Date.now()+FulfillmentService.leadMinutes(containsCake)*60_000)err(400,containsCake?'Bolos personalizados precisam de 2 horas de antecedência.':'Agende com pelo menos 45 minutos de antecedência.');if(dt.getTime()>Date.now()+14*86400000)err(400,'Agendamentos disponíveis para os próximos 14 dias.');}
function priceFor(product,custom){return new Product(product).calculate(custom)}
function orderTransaction(user,info){const method=info.payment_method,fulfillment=info.fulfillment;
 if(!['pix','card','meal'].includes(method))err(400,'Selecione a forma de pagamento.');if(!['pickup','delivery'].includes(fulfillment))err(400,'Selecione retirada ou entrega.');
 const name=safeText(info.customer_name,90),phone=safeText(info.phone,25),address=safeText(info.address,220),notes=safeText(info.notes,450),slot=safeText(info.slot,22);
 if(name.length<3||phone.replace(/\D/g,'').length<10)err(400,'Informe seu nome e um telefone válido.');if(fulfillment==='delivery'&&address.length<12)err(400,'Informe o endereço completo para entrega.');
 if(!Array.isArray(info.items)||info.items.length<1||info.items.length>25)err(400,'Seu carrinho está vazio ou excedeu o limite de itens.');
 db.exec('BEGIN IMMEDIATE');
 try{
  let subtotal=0;let totalQty=0;let cake=false;const resolved=[];
  for(const item of info.items){const qty=Number(item.quantity),id=Number(item.product_id);if(!Number.isInteger(qty)||qty<1||qty>25||!Number.isInteger(id))err(400,'Quantidade inválida.');const product=db.prepare('SELECT * FROM products WHERE id=? AND available=1').get(id);if(!product)err(400,'Um dos produtos não está disponível.');if(product.stock<qty)err(409,`Estoque insuficiente para ${product.name}. Restam ${product.stock} unidades.`);const priced=priceFor(product,item.customization||{});subtotal+=priced.unit_cents*qty;totalQty+=qty;if(product.category==='bolos'&&Object.keys(parseOptions(product.options_json)).length)cake=true;resolved.push({product,quantity:qty,...priced});}
  if(totalQty>60)err(400,'Limite de 60 unidades por pedido.');validateSlot(slot,cake);
  const delivery=FulfillmentService.deliveryFeeCents(fulfillment,subtotal),total=subtotal+delivery;
  const code='FR-'+crypto.randomBytes(4).toString('hex').toUpperCase();const payment_status=method==='pix'?'aguardando_demo':'aprovado_demo';
  const r=db.prepare('INSERT INTO orders(code,user_id,customer_name,email,phone,fulfillment,address,slot,notes,payment_method,payment_status,status,subtotal_cents,delivery_cents,total_cents) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(code,user.id,name,user.email,phone,fulfillment,address,slot,notes,method,payment_status,'recebido',subtotal,delivery,total);
  const insert=db.prepare('INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_cents,customization_json) VALUES(?,?,?,?,?,?)');
  const update=db.prepare('UPDATE products SET stock=stock-? WHERE id=? AND stock>=?');
  for(const i of resolved){insert.run(r.lastInsertRowid,i.product.id,i.product.name,i.quantity,i.unit_cents,JSON.stringify(i.customization));if(update.run(i.quantity,i.product.id,i.quantity).changes!==1)err(409,'Estoque atualizado durante sua compra.');}
  db.exec('COMMIT');const result=orderFull(db.prepare('SELECT * FROM orders WHERE id=?').get(r.lastInsertRowid));broadcast('orders',{type:'new',code});return result;
 }catch(e){db.exec('ROLLBACK');throw e}}
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.ico':'image/x-icon'};
function staticResponse(req,res,pathname){const requested=pathname==='/'?'/index.html':pathname;let safe;try{safe=decodeURIComponent(requested)}catch{err(400,'Caminho inválido.')}const target=path.resolve(root,'.'+safe);if(!target.startsWith(root+path.sep))return err(404,'Arquivo não encontrado.');let stat;try{stat=fs.statSync(target)}catch{return err(404,'Página não encontrada.')}if(!stat.isFile())return err(404,'Página não encontrada.');res.writeHead(200,{'content-type':mime[path.extname(target).toLowerCase()]||'application/octet-stream','cache-control':target.endsWith('.html')?'no-store':'public, max-age=3600'});fs.createReadStream(target).pipe(res)}
async function api(req,res,pathname,search){const method=req.method;
 if(method==='GET'&&pathname==='/api/health')return json(res,200,{ok:true,site:'Fornê Bakery',time:new Date().toISOString()});
 if(method==='GET'&&pathname==='/api/products'){
  const where=['1=1'],args=[];if(search.get('category')&&allowedCategories.has(search.get('category'))){where.push('category=?');args.push(search.get('category'))}if(search.get('search')){where.push('(name LIKE ? OR description LIKE ?)');const q='%'+safeText(search.get('search'),80)+'%';args.push(q,q)}if(search.get('featured')==='1')where.push('featured=1');if(search.get('all')!=='1')where.push('available=1');else requires(req,'admin');
  return json(res,200,{products:db.prepare(`SELECT * FROM products WHERE ${where.join(' AND ')} ORDER BY featured DESC,id ASC`).all(...args).map(formatted)});
 }
 if(method==='GET'&&pathname==='/api/me')return json(res,200,{user:auth(req)});
 if(method==='POST'&&pathname==='/api/auth/register'){
  const b=await bodyJson(req);const name=safeText(b.name,80),email=safeText(b.email,140).toLowerCase(),password=String(b.password||''),phone=safeText(b.phone,25);
  if(name.length<3||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<8||password.length>128)err(400,'Informe nome, e-mail válido e senha com pelo menos 8 caracteres.');if(db.prepare('SELECT id FROM users WHERE email=?').get(email))err(409,'Este e-mail já está cadastrado.');const salt=crypto.randomBytes(16).toString('hex');const u=db.prepare('INSERT INTO users(name,email,phone,salt,hash,role) VALUES(?,?,?,?,?,?)').run(name,email,phone,salt,passwd(password,salt),'customer');const user={id:Number(u.lastInsertRowid),name,email,phone,role:'customer'};return json(res,201,{user},{'set-cookie':startSession(user,res)});
 }
 if(method==='POST'&&pathname==='/api/auth/login'){
  const b=await bodyJson(req);const email=safeText(b.email,140).toLowerCase(),password=String(b.password||'');const key=(req.socket.remoteAddress||'local')+':'+email;const attempt=badLogins.get(key);if(attempt?.blocked>Date.now())err(429,'Muitas tentativas. Tente novamente em alguns minutos.');const record=db.prepare('SELECT * FROM users WHERE email=?').get(email);const pretendSalt='00000000000000000000000000000000';const actual=passwd(password.slice(0,128),record?.salt||pretendSalt);if(!record||!crypto.timingSafeEqual(Buffer.from(actual,'hex'),Buffer.from(record.hash,'hex'))){const n=(attempt?.count||0)+1;badLogins.set(key,{count:n,blocked:n>=8?Date.now()+5*60000:0});err(401,'E-mail ou senha incorretos.')}badLogins.delete(key);const user=privateUser(record);return json(res,200,{user},{'set-cookie':startSession(user,res)});
 }
 if(method==='POST'&&pathname==='/api/auth/logout'){
  const token=cookies(req).forne_session;if(token)db.prepare('DELETE FROM sessions WHERE token_hash=?').run(crypto.createHash('sha256').update(token).digest('hex'));return json(res,200,{ok:true},{'set-cookie':sessionCookie('',0)});
 }
 if(method==='GET'&&pathname==='/api/orders'){const user=requires(req);const rows=db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 100').all(user.id);return json(res,200,{orders:rows.map(orderFull)});}
 if(method==='POST'&&pathname==='/api/orders'){const user=requires(req);const b=await bodyJson(req);return json(res,201,{order:orderTransaction(user,b)});}
 const orderMatch=pathname.match(/^\/api\/orders\/(FR-[A-F0-9]{8})(?:\/(demo-confirm))?$/);
 if(orderMatch){const code=orderMatch[1];const user=requires(req);const row=db.prepare('SELECT * FROM orders WHERE code=?').get(code);if(!row||(row.user_id!==user.id&&user.role!=='admin'))err(404,'Pedido não encontrado.');
  if(method==='GET'&&!orderMatch[2])return json(res,200,{order:orderFull(row)});
  if(method==='POST'&&orderMatch[2]){if(row.payment_method!=='pix'||row.payment_status!=='aguardando_demo')err(409,'Este pedido não está aguardando confirmação Pix de demonstração.');db.prepare("UPDATE orders SET payment_status='aprovado_demo',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(row.id);broadcast('orders',{type:'payment',code});return json(res,200,{order:orderFull(db.prepare('SELECT * FROM orders WHERE id=?').get(row.id))});}
 }
 if(pathname==='/api/kitchen/stream'&&method==='GET'){
  requires(req,'admin');res.writeHead(200,{'content-type':'text/event-stream','cache-control':'no-cache,no-transform','connection':'keep-alive','x-accel-buffering':'no'});res.write(`event: connected\ndata: {"ok":true}\n\n`);streams.add(res);const ping=setInterval(()=>{try{res.write(': ping\n\n')}catch{clearInterval(ping);streams.delete(res)}},20000);req.on('close',()=>{clearInterval(ping);streams.delete(res)});return;
 }
 if(pathname==='/api/kitchen/orders'&&method==='GET'){
  requires(req,'admin');const filters=[],args=[];if(search.get('status')&&statuses.includes(search.get('status'))){filters.push('status=?');args.push(search.get('status'))}if(search.get('date')&&/^\d{4}-\d{2}-\d{2}$/.test(search.get('date'))){filters.push('substr(created_at,1,10)=?');args.push(search.get('date'))}const clause=filters.length?'WHERE '+filters.join(' AND '):'';const list=db.prepare(`SELECT * FROM orders ${clause} ORDER BY id DESC LIMIT 200`).all(...args).map(orderFull);return json(res,200,{orders:list});
 }
 if(pathname==='/api/kitchen/stats'&&method==='GET'){
  requires(req,'admin');const summary=db.prepare("SELECT COUNT(*) total_orders,COALESCE(SUM(CASE WHEN payment_status='aprovado_demo' AND status<>'cancelado' THEN total_cents ELSE 0 END),0) revenue_cents, SUM(CASE WHEN status='recebido' AND payment_status='aprovado_demo' THEN 1 ELSE 0 END) pending, SUM(CASE WHEN status='em_preparo' THEN 1 ELSE 0 END) preparing, SUM(CASE WHEN status='pronto' THEN 1 ELSE 0 END) ready FROM orders").get();const categories=db.prepare("SELECT p.category, SUM(oi.quantity) quantity FROM order_items oi JOIN products p ON p.id=oi.product_id JOIN orders o ON o.id=oi.order_id WHERE o.status<>'cancelado' GROUP BY p.category ORDER BY quantity DESC").all();const best=db.prepare("SELECT product_name name,SUM(quantity) qty FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status<>'cancelado' GROUP BY product_name ORDER BY qty DESC LIMIT 5").all();const daily=db.prepare("SELECT substr(created_at,1,10) date,SUM(total_cents) revenue_cents FROM orders WHERE payment_status='aprovado_demo' AND status<>'cancelado' AND created_at >= date('now','-6 days') GROUP BY substr(created_at,1,10) ORDER BY date").all();return json(res,200,{summary,categories,best,daily});
 }
 const statusMatch=pathname.match(/^\/api\/kitchen\/orders\/(\d+)\/status$/);
 if(statusMatch&&method==='PATCH'){
  requires(req,'admin');const id=Number(statusMatch[1]),b=await bodyJson(req),value=safeText(b.status,30);const row=db.prepare('SELECT * FROM orders WHERE id=?').get(id);if(!row)err(404,'Pedido não encontrado.');if(row.payment_status!=='aprovado_demo')err(409,'Confirme o pagamento de demonstração antes de preparar.');if(!Order.canTransition(row.status,value))err(409,'Mudança de status não permitida.');db.exec('BEGIN IMMEDIATE');try{if(value==='cancelado'){const items=db.prepare('SELECT product_id,quantity FROM order_items WHERE order_id=?').all(id);for(const item of items)db.prepare('UPDATE products SET stock=stock+? WHERE id=?').run(item.quantity,item.product_id);}db.prepare('UPDATE orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(value,id);db.exec('COMMIT')}catch(e){db.exec('ROLLBACK');throw e}broadcast('orders',{type:'status',code:row.code,status:value});return json(res,200,{order:orderFull(db.prepare('SELECT * FROM orders WHERE id=?').get(id))});
 }
 if(pathname==='/api/kitchen/products'&&method==='POST'){
  requires(req,'admin');const b=await bodyJson(req);const p=validateProduct(b);const result=db.prepare('INSERT INTO products(name,description,category,price_cents,stock,artwork,image_url,badge,featured,available,options_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(...Object.values(p));broadcast('products',{type:'new'});return json(res,201,{product:formatted(db.prepare('SELECT * FROM products WHERE id=?').get(result.lastInsertRowid))});
 }
 const productId=pathname.match(/^\/api\/kitchen\/products\/(\d+)$/);
 if(productId&&method==='PATCH'){
  requires(req,'admin');const id=Number(productId[1]);const existing=db.prepare('SELECT * FROM products WHERE id=?').get(id);if(!existing)err(404,'Produto não encontrado.');const b=await bodyJson(req);const p=validateProduct({...formatted(existing),...b});db.prepare('UPDATE products SET name=?,description=?,category=?,price_cents=?,stock=?,artwork=?,image_url=?,badge=?,featured=?,available=?,options_json=? WHERE id=?').run(...Object.values(p),id);broadcast('products',{type:'edit',id});return json(res,200,{product:formatted(db.prepare('SELECT * FROM products WHERE id=?').get(id))});
 }
 if(productId&&method==='DELETE'){
  requires(req,'admin');const id=Number(productId[1]);if(!db.prepare('SELECT id FROM products WHERE id=?').get(id))err(404,'Produto não encontrado.');db.prepare('UPDATE products SET available=0 WHERE id=?').run(id);broadcast('products',{type:'archive',id});return json(res,200,{ok:true});
 }
 if(pathname==='/api/kitchen/report.csv'&&method==='GET'){
  requires(req,'admin');const rows=db.prepare('SELECT code,customer_name,email,phone,fulfillment,slot,payment_method,payment_status,status,total_cents,created_at FROM orders ORDER BY id DESC').all();const keys=['code','customer_name','email','phone','fulfillment','slot','payment_method','payment_status','status','total_cents','created_at'];const escape=v=>'"'+String(v??'').replace(/^([=+@\-])/,'\u0027$1').replace(/"/g,'""')+'"';const content='\ufeff'+keys.join(';')+'\n'+rows.map(x=>keys.map(k=>escape(x[k])).join(';')).join('\n');res.writeHead(200,{'content-type':'text/csv; charset=utf-8','content-disposition':'attachment; filename="relatorio-forne.csv"','cache-control':'no-store'});res.end(content);return;
 }
 return err(404,'Rota não encontrada.');
}
function validateProduct(b){const name=safeText(b.name,100),description=safeText(b.description,350),category=safeText(b.category,30),price=Number(b.price_cents),stock=Number(b.stock),artwork=safeText(b.artwork,30),badge=safeText(b.badge,32),image_url=safeText(b.image_url,400),featured=b.featured?1:0,available=b.available===false?0:1,options=b.options||{};if(name.length<3||description.length<6||!allowedCategories.has(category)||!money(price)||price>500000||!money(stock)||stock>100000)err(400,'Dados de produto inválidos.');if(image_url&&!/^https:\/\//.test(image_url))err(400,'A imagem deve usar um endereço HTTPS.');if(Object.keys(options).length>0){if(!Array.isArray(options.size)||!Array.isArray(options.filling))err(400,'Configuração de variações inválida.')}return {name,description,category,price,stock,artwork:allowedArtworks.has(artwork)?artwork:'bread',image_url,badge,featured,available,options_json:JSON.stringify(options)};}
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
 try{const url=new URL(req.url,'http://localhost');const pathname=url.pathname;const origin=req.headers.origin;if(['POST','PATCH','DELETE','PUT'].includes(req.method)&&origin&&origin!==`http://${req.headers.host}`&&origin!==`https://${req.headers.host}`)err(403,'Origem não permitida.');if(pathname.startsWith('/api/'))await api(req,res,pathname,url.searchParams);else if(req.method==='GET'||req.method==='HEAD')staticResponse(req,res,pathname);else err(405,'Método não permitido.');}
 catch(e){if(!res.writableEnded&&!res.headersSent){const status=e.status||500;if(status>=500)console.error(e);json(res,status,{error:status>=500?'Erro inesperado no servidor.':e.message})}else if(!res.writableEnded)res.end()}
});
if(require.main===module)server.listen(PORT,()=>{console.log('\n  🍞  Fornê Bakery iniciado!');console.log(`  ➜  http://localhost:${PORT}`);console.log('  Painel: /#cozinha   |   Demo: cozinha@forne.com.br / Forne@123\n');});
module.exports={server,priceFor,validateSlot};
