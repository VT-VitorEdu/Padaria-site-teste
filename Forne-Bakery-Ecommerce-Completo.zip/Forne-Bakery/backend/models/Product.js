'use strict';
/** Encapsula a representação de produto e sua precificação por variação. */
class Product {
  constructor(row) { this.row = row; }
  get options() {try {return JSON.parse(this.row.options_json || '{}');} catch {return {};}}
  calculate(customization={}) {
    let unit_cents = this.row.price_cents;
    const chosen = {};
    for (const key of ['size', 'filling']) {
      const choices = this.options[key];
      if (Array.isArray(choices) && choices.length) {
        const pick = choices.find(choice=>choice.label===customization[key]) || choices[0];
        unit_cents += pick.extra;
        chosen[key] = pick.label;
      }
    }
    if (this.options.message) chosen.message=String(customization.message||'').trim().slice(0,60);
    return {unit_cents, customization:chosen};
  }
  toJSON() {
    const {options_json,...data}=this.row;
    return {...data,options:this.options,featured:!!data.featured,available:!!data.available};
  }
}
module.exports=Product;
