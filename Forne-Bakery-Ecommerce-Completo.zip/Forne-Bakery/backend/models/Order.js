'use strict';
/** Regras de transição de pedidos para o fluxo de produção. */
class Order {
  static transitions={
    recebido:['em_preparo','cancelado'],
    em_preparo:['pronto','cancelado'],
    pronto:['concluido'],
    concluido:[],
    cancelado:[]
  };
  static canTransition(current,next){return (this.transitions[current]||[]).includes(next)}
}
module.exports=Order;
