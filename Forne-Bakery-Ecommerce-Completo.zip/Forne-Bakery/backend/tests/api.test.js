'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {tmpdir}=require('node:os');
const fs=require('node:fs');
const path=require('node:path');
const dir=fs.mkdtempSync(path.join(tmpdir(),'forne-test-'));
process.env.FORNE_DB_PATH=path.join(dir,'test.sqlite');
const {server}=require('../server');
let port,customerCookie,adminCookie;
async function call(endpoint,{method='GET',body,cookie}={}){const res=await fetch(`http://127.0.0.1:${port}${endpoint}`,{method,headers:{...(body?{'content-type':'application/json'}:{}),...(cookie?{cookie}:{})},body:body?JSON.stringify(body):undefined});const text=await res.text();let data;try{data=JSON.parse(text)}catch{data=text}return {status:res.status,data,cookie:res.headers.get('set-cookie'),headers:res.headers};}
test.before(async()=>{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));port=server.address().port});
test.after(async()=>{await new Promise(resolve=>server.close(resolve));fs.rmSync(dir,{recursive:true,force:true})});
test('servidor, vitrine, filtros e arquivos estáticos',async()=>{
 const health=await call('/api/health');assert.equal(health.status,200);assert.equal(health.data.ok,true);
 const catalog=await call('/api/products');assert.equal(catalog.status,200);assert.equal(catalog.data.products.length,15);
 const filtered=await call('/api/products?category=bolos');assert.ok(filtered.data.products.every(p=>p.category==='bolos'));assert.ok(filtered.data.products.some(p=>p.options.size));
 const page=await call('/');assert.equal(page.status,200);assert.match(page.data,/Fornê Bakery/);
 const img=await call('/assets/products/croissant.svg');assert.equal(img.status,200);
});
test('login, sessão, credenciais e acesso restrito',async()=>{
 const deny=await call('/api/kitchen/orders');assert.equal(deny.status,401);
 const bad=await call('/api/auth/login',{method:'POST',body:{email:'cliente@forne.com.br',password:'senha-incorreta'}});assert.equal(bad.status,401);
 const c=await call('/api/auth/login',{method:'POST',body:{email:'cliente@forne.com.br',password:'Cliente@123'}});assert.equal(c.status,200);customerCookie=c.cookie.split(';')[0];assert.equal(c.data.user.role,'customer');
 const denyAdmin=await call('/api/kitchen/orders',{cookie:customerCookie});assert.equal(denyAdmin.status,403);
 const a=await call('/api/auth/login',{method:'POST',body:{email:'cozinha@forne.com.br',password:'Forne@123'}});assert.equal(a.status,200);adminCookie=a.cookie.split(';')[0];
});
let order;
test('checkout do bolo personalizado com cálculo no servidor e estoque',async()=>{
 const products=(await call('/api/products')).data.products;const cake=products.find(p=>p.name==='Bolo de aniversário');const before=cake.stock;
 const dt=new Date(Date.now()+2*86400000);const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(dt).filter(x=>x.type!=='literal').map(x=>[x.type,x.value]));const day=`${parts.year}-${parts.month}-${parts.day}`;
 const payload={customer_name:'Cliente Demonstração',phone:'11999998888',fulfillment:'delivery',address:'Rua Fictícia, 125 - Bairro Jardim',slot:day+'T14:00',payment_method:'pix',items:[{product_id:cake.id,quantity:2,customization:{size:'2 kg · até 16 fatias',filling:'Morango com creme',message:'Viva!' }}]};
 const placed=await call('/api/orders',{method:'POST',cookie:customerCookie,body:payload});assert.equal(placed.status,201,JSON.stringify(placed.data));order=placed.data.order;assert.equal(order.payment_status,'aguardando_demo');assert.equal(order.items[0].unit_cents,18090);assert.equal(order.total_cents,36180);assert.equal(order.delivery_cents,0);
 const after=(await call('/api/products')).data.products.find(p=>p.id===cake.id);assert.equal(after.stock,before-2);
 const inaccessible=await call('/api/orders/'+order.code);assert.equal(inaccessible.status,401);
 const owner=await call('/api/orders/'+order.code,{cookie:customerCookie});assert.equal(owner.status,200);
});
test('estoque bloqueia quantidade indisponível e cancela transação',async()=>{
 const item=(await call('/api/products')).data.products.find(p=>p.name==='Croissant de manteiga');const day=new Date(Date.now()+2*86400000);const d=new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(day);
 const res=await call('/api/orders',{method:'POST',cookie:customerCookie,body:{customer_name:'Teste',phone:'11999998888',fulfillment:'pickup',slot:d+'T12:00',payment_method:'card',items:[{product_id:item.id,quantity:25},{product_id:item.id,quantity:25}]}});assert.equal(res.status,409);
 const after=(await call('/api/products')).data.products.find(p=>p.id===item.id);assert.equal(after.stock,item.stock);
});
test('pix de demonstração, fila da cozinha, atualização de status e relatórios',async()=>{
 const pending=await call('/api/kitchen/orders',{cookie:adminCookie});assert.equal(pending.status,200);assert.ok(pending.data.orders.find(x=>x.code===order.code));
 const forbidden=await call(`/api/kitchen/orders/${order.id}/status`,{method:'PATCH',cookie:adminCookie,body:{status:'em_preparo'}});assert.equal(forbidden.status,409);
 const confirm=await call(`/api/orders/${order.code}/demo-confirm`,{method:'POST',cookie:customerCookie,body:{}});assert.equal(confirm.status,200);assert.equal(confirm.data.order.payment_status,'aprovado_demo');
 const steps=['em_preparo','pronto','concluido'];for(const status of steps){const result=await call(`/api/kitchen/orders/${order.id}/status`,{method:'PATCH',cookie:adminCookie,body:{status}});assert.equal(result.status,200);assert.equal(result.data.order.status,status)}
 const stats=await call('/api/kitchen/stats',{cookie:adminCookie});assert.equal(stats.status,200);assert.equal(stats.data.summary.total_orders,1);assert.equal(stats.data.summary.revenue_cents,36180);
 const report=await call('/api/kitchen/report.csv',{cookie:adminCookie});assert.equal(report.status,200);assert.match(report.data,/(FR-)/);
});
test('criação e atualização de produto só por administradores',async()=>{
 const p={name:'Mini brioche',description:'Brioche artesanal com manteiga e mel.',category:'paes',price_cents:790,stock:22,artwork:'bread',badge:'Novo',featured:true,available:true,options:{}};
 const forbidden=await call('/api/kitchen/products',{method:'POST',cookie:customerCookie,body:p});assert.equal(forbidden.status,403);
 const created=await call('/api/kitchen/products',{method:'POST',cookie:adminCookie,body:p});assert.equal(created.status,201);const id=created.data.product.id;
 const updated=await call('/api/kitchen/products/'+id,{method:'PATCH',cookie:adminCookie,body:{price_cents:890,stock:12}});assert.equal(updated.status,200);assert.equal(updated.data.product.price_cents,890);
 const removed=await call('/api/kitchen/products/'+id,{method:'DELETE',cookie:adminCookie});assert.equal(removed.status,200);
 const catalog=(await call('/api/products')).data.products;assert.ok(!catalog.find(x=>x.id===id));
});
